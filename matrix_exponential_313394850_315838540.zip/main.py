import math
import numpy as np
import scipy.linalg as sc
import timeit

def readMatrixInputFromFile(fileName):
    '''
    Return Data read from the text file\n
    :param fileName: file name
    :return: Data read from the text file
    '''

    return np.loadtxt(fileName, dtype=np.float64, delimiter=',')

def calcTylor(matrix):
    # get the size of the matrix
    rowNum, colNum = np.shape(matrix)
    # create a unit matrix depends on the size of the given matrix
    unitMatrix = np.eye(rowNum, colNum)
    # find the C value for Lagrange Reminder
    c = np.sqrt(power_iteration(matrix))

    epsilon = 0.0000000001
    tylorMatrix = unitMatrix + matrix
    multiplyedMatrix = matrix
    multiplyedDenom = 1
    i = 2

    while True:
        multiplyedMatrix = np.dot(multiplyedMatrix, matrix)
        multiplyedDenom = multiplyedDenom * i
        coefficient = 1 / multiplyedDenom
        tylorMatrix = tylorMatrix + (coefficient * multiplyedMatrix)

        #calculate reminder
        coefficient_reminder = np.power(math.e,c) / multiplyedDenom * (i+1)
        reminder = coefficient_reminder * math.pow(c,i+1)
        i = i + 1
        #print(i)

        if reminder < epsilon:
            break

    return tylorMatrix

def calcAtA(matrix):
    # calculate transpose_matrix * matrix
    tranposeMatrix = np.transpose(matrix)
    aTa = tranposeMatrix.dot(matrix)
    return aTa

def calcVectorNorm(vector):
    return np.sqrt(np.dot(vector,vector))

def eigenvalue(A, v):
    '''
    Return the eigenvalue
    Av =xV
    :param A: matrix
    :param v: vector
    :return: eigenvalue
    '''
    Av = A.dot(v)
    return v.dot(Av)

def power_iteration(A):
    '''
    Return the biggest eigenvalue and eigenvector
    :param A: matrix
    :return: the biggest eigenvalue of a matrix
    '''
    row, col = A.shape

    v = np.ones(col) / np.sqrt(col)
    ev = eigenvalue(A, v)

    while True:
        Av = A.dot(v)
        v_new = Av / calcVectorNorm(Av)

        ev_new = eigenvalue(A, v_new)
        if np.abs(ev - ev_new) < 0.0000000001:
            break

        ev = ev_new

    return ev_new


#main
A = readMatrixInputFromFile("inv_matrix(1000x1000).txt")

start = timeit.default_timer()
our_exponential_matrix = calcTylor(A)
stop = timeit.default_timer()
print('Our Time: ', stop - start)

start = timeit.default_timer()
python_exponential_matrix = sc.expm(A)
stop = timeit.default_timer()
print('Python Time: ', stop - start)





















